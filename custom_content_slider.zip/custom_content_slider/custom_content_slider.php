<?php
/*
Plugin Name: Custom Content Slider and Recent Posts Widget
Description: This plugin adds a shortcode for a content slider and a widget for recent posts.
Version: 1.0
Author: Abhijit Sharma
*/


// Enqueue necessary scripts and styles for the slider
function custom_content_slider_scripts() {
    // Enqueue slick slider CSS and JS files
    wp_enqueue_style('slick-slider', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_script('slick-slider', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), null, true);

    // Enqueue custom script for slider initialization
    wp_enqueue_script('custom-slider-init', plugin_dir_url(__FILE__) . 'custom-slider-init.js', array('jquery', 'slick-slider'), null, true);
}
add_action('wp_enqueue_scripts', 'custom_content_slider_scripts');

// Create a custom post type for slider items
function custom_content_slider_post_type() {
    $args = array(
        'public' => true,
        'label'  => 'Slider Items',
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
    );
    register_post_type('slider_item', $args);
}
add_action('init', 'custom_content_slider_post_type');


// Implement a shortcode to display a dynamic content slider
function custom_content_slider($atts) {
    // Shortcode attributes
    $atts = shortcode_atts(array(
        'posts_per_page' => 5, // Number of slides to display
    ), $atts);

    // Query slider items
    $args = array(
        'post_type' => 'slider_item',
        'posts_per_page' => $atts['posts_per_page'],
    );
    $slider_query = new WP_Query($args);

    // Slider markup
    $output = '<div class="custom-content-slider">';
    if ($slider_query->have_posts()) {
        while ($slider_query->have_posts()) {
            $slider_query->the_post();
            $output .= '<div class="slide">';
            $output .= '<h3>' . the_post_thumbnail() . '</h3>';
            $output .= '<div class="slide-content">' . get_the_content() . '</div>';
            $output .= '</div>';
        }
        wp_reset_postdata();
    } else {
        $output .= '<p>No slides found.</p>';
    }
    $output .= '</div>';

    return $output;
}
add_shortcode('custom_content_slider', 'custom_content_slider');



// Include a widget to showcase recent posts with featured images
class Recent_Posts_Widget extends WP_Widget {

    // Set up the widget name and description
    public function __construct() {
        $widget_options = array(
            'classname' => 'recent_posts_widget',
            'description' => 'This widget displays recent posts with featured images',
        );
        parent::__construct('recent_posts_widget', 'Recent Posts Widget', $widget_options);
    }

    // Create the widget output
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $post_count = !empty($instance['post_count']) ? $instance['post_count'] : 5;

        echo $args['before_widget'] . $args['before_title'] . $title . $args['after_title'];

        $query_args = array(
            'post_type' => 'post',
            'posts_per_page' => $post_count,
        );
        $the_query = new WP_Query($query_args);

        if ($the_query->have_posts()) {
            echo '<ul>';
            while ($the_query->have_posts()) {
                $the_query->the_post();
                echo '<li><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></li>';
                if (has_post_thumbnail()) {
                    the_post_thumbnail();
                }
            }
            echo '</ul>';
        } else {
            echo 'No recent posts';
        }

        echo $args['after_widget'];
    }

    // Output the options form on admin
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $post_count = !empty($instance['post_count']) ? $instance['post_count'] : 5;
        ?>
<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
    <input type="text" id="<?php echo $this->get_field_id('title'); ?>"
        name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>" />
</p>
<p>
    <label for="<?php echo $this->get_field_id('post_count'); ?>">Number of posts to show:</label>
    <input type="number" id="<?php echo $this->get_field_id('post_count'); ?>"
        name="<?php echo $this->get_field_name('post_count'); ?>" value="<?php echo esc_attr($post_count); ?>" />
</p>
<?php
    }

    // Process widget options to be saved
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['post_count'] = is_numeric($new_instance['post_count']) ? $new_instance['post_count'] : 5;
        return $instance;
    }
}

// Register the widget
function register_recent_posts_widget() {
    register_widget('Recent_Posts_Widget');
}
add_action('widgets_init', 'register_recent_posts_widget');






// Utilize AJAX for dynamic content loading
add_action('wp_ajax_my_action', 'my_action');
add_action('wp_ajax_nopriv_my_action', 'my_action');
function my_action() {
    // You need to implement the actual logic for the AJAX request here.
    wp_die(); // this is required to terminate immediately and return a proper response
}

// Create a settings page in the admin dashboard
add_action('admin_menu', 'my_plugin_menu');
function my_plugin_menu() {
    add_options_page('My Plugin Options', 'My Plugin', 'manage_options', 'my-plugin', 'my_plugin_options');
}
function my_plugin_options() {
    // You need to implement the actual logic for the settings page here.
    echo '<div class="wrap"><p>Here is where the form would go if I actually had options.</p></div>';
}




// Step 1: Add Menu Item
function custom_plugin_add_menu() {
    add_menu_page(
        'Custom Plugin Settings',    // Page title
        'Custom Plugin',             // Menu title
        'manage_options',            // Capability required
        'custom-plugin-settings',    // Menu slug
        'custom_plugin_settings_page', // Callback function to render the page
        'dashicons-admin-settings',  // Icon
        100                          // Position
    );
}
add_action('admin_menu', 'custom_plugin_add_menu');

// Step 2: Create Settings Page
function custom_plugin_settings_page() {
    ?>
<div class="wrap">
    <h2>Custom Plugin Settings</h2>
    <form method="post" action="options.php">
        <?php
            // Output nonce, action, and option_page fields for security
            settings_fields('custom_plugin_settings');
            // Output setting sections and their fields
            do_settings_sections('custom_plugin_settings');
            // Output save settings button
            submit_button('Save Settings');
            ?>
    </form>
</div>
<?php
}

// Step 3: Save and Retrieve Settings
function custom_plugin_register_settings() {
    // Register a setting and its sanitization callback
    register_setting('custom_plugin_settings', 'custom_plugin_option', 'sanitize_callback');
    // Add a section and its fields
    add_settings_section('custom_plugin_main_section', 'Main Settings', 'custom_plugin_section_callback', 'custom_plugin_settings');
    add_settings_field('custom_plugin_field', 'Custom Field', 'custom_plugin_field_callback', 'custom_plugin_settings', 'custom_plugin_main_section');
}
add_action('admin_init', 'custom_plugin_register_settings');

// Step 4: Sanitize and Validate Input
function sanitize_callback($input) {
    // Sanitize and validate input here
    return $input;
}

// Step 5: Display Feedback
function custom_plugin_section_callback() {
    echo '<p>Enter your settings below:</p>';
}

function custom_plugin_field_callback() {
    $option_value = get_option('custom_plugin_option');
    echo '<input type="text" id="custom_plugin_field" name="custom_plugin_option" value="' . esc_attr($option_value) . '" />';
}

















?>