# Moveinsync WordPress Theme

## Overview

Moveinsync is a custom WordPress theme designed for a SaaS product that manages workplaces. The theme is tailored for HR managers, workplace managers, and facility managers with a focus on user experience and brand consistency.

## Theme Features

### Responsive Design

The theme provides a responsive design, ensuring a seamless experience across desktop and mobile devices.

### Custom Post Types and Taxonomies

Introduces custom post types and taxonomies for managing desks, meeting rooms, parking, and visitors.

### Custom Page Templates

Includes custom page templates for the homepage, solution page, and resource page, providing a tailored layout for each.

### Advanced Custom Fields (ACF) Integration

Utilizes Advanced Custom Fields (ACF) for enhanced content flexibility, allowing easy customization of content elements.

### Customizable Color Schemes

Employs the theme customizer to offer customizable color schemes, aligning with the Sage & Hero brand archetype.

### WordPress Best Practices

Developed following WordPress best practices and coding standards for maintainability and compatibility.

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
