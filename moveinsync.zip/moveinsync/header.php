<!DOCTYPE html>
<html lang="en">



<body>
    <?php wp_head(); ?>
 

    <div class="container header position-relative overflow-hidden p-0">
        <nav class="navbar navbar-expand-lg fixed-top navbar-light px-4 px-lg-5 py-3 py-lg-0">
            <a href="<?php echo site_url(); ?>" class="navbar-brand p-0">
                <?php $logoimg = get_header_image(); ?>
                <img src="<?php echo $logoimg; ?>" alt="Logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto py-0">
                    <?php wp_nav_menu(array('theme_location' => 'primary-menu-key', 'menu_class' => 'nav-link')) ?>
                </ul>
                <div class="d-flex mt-3 mt-lg-0">
                    <a href="#" class="btn btn-light border border-primary rounded-pill text-primary py-2 px-4 me-4">Log
                        In</a>
                    <a href="#" class="btn btn-primary rounded-pill text-white py-2 px-4">Sign Up</a>
                </div>
            </div>
        </nav>
    </div>