<?php 
 /* Template Name: About Us */
get_header();


?>
<div class="container-fluid bg-breadcrumb">
    <ul class="breadcrumb-animation">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
    <div class="container text-center py-5" style="max-width: 900px;">
        <h3 class="display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">About Us</h1>
            <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>">Home</a></li>
                <li class="breadcrumb-item active text-primary">About</li>
            </ol>
    </div>
</div>


<div class="container-fluid overflow-hidden py-5 mt-5">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="RotateMoveLeft">

                    <img src="<?php echo get_template_directory_uri(); ?>/img/about-1.png" class="img-fluid w-100"
                        alt="">
                </div>
            </div>
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                <h4 class="mb-1 text-primary">About Us</h4>
                <h1 class="display-5 mb-4">Get Started Easily With a Personalized Product Tour</h1>
                <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, suscipit itaque
                    quaerat dicta porro illum, autem, molestias ut animi ab aspernatur dolorum officia nam dolore.
                    Voluptatibus aliquam earum labore atque.
                </p>
                <a href="#" class="btn btn-primary rounded-pill py-3 px-5">About More</a>
            </div>
        </div>
    </div>
</div>
<!-- About End -->


<!-- Feature Start -->
<div class="container-fluid feature overflow-hidden py-5">
    <div class="container py-5">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 900px;">
            <h4 class="text-primary">Our Feature</h4>
            <h1 class="display-5 mb-4">Important Features For Email Marketing</h1>
            <p class="mb-0">Dolor sit amet consectetur, adipisicing elit. Ipsam, beatae maxime. Vel animi
                eveniet
                doloremque reiciendis soluta iste provident non rerum illum perferendis earum est architecto
                dolores
                vitae quia vero quod incidunt culpa corporis, porro doloribus. Voluptates nemo doloremque cum.
            </p>
        </div>
        <div class="row g-4 justify-content-center text-center mb-5">
            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                <div class="text-center p-4">
                    <div class="d-inline-block rounded bg-light p-4 mb-4"><i
                            class="fa fa-handshake fa-5x text-secondary"></i></div>
                    <div class="feature-content">
                        <a href="#" class="h4">Desk Management <i class="fa fa-long-arrow-alt-right"></i></a>
                        <p class="mt-4 mb-0">

                        <ul class="text-start">
                            <li>Real-time desk availability tracking.</li>
                            <li> Easy desk assignment and reservation.</li>
                            <li> Customizable desk layouts for different office configurations. </li>
                            <li> Integration withemployee directories for seamless allocation. </li>
                        </ul>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                <div class="text-center rounded p-4">
                    <div class="d-inline-block rounded bg-light p-4 mb-4"><i
                            class="fas fa-school fa-5x text-secondary"></i></div>
                    <div class="feature-content">
                        <a href="#" class="h4">Meeting Room <i class="fa fa-long-arrow-alt-right"></i></a>
                        <p class="mt-4 mb-0">
                        <ul class="text-start">
                            <li> Intuitive calendar-based booking system.</li>
                            <li> Automated notifications for upcoming meetings.</li>
                            <li> Resource scheduling for equipment and amenities.</li>
                            <li> Instant room release for no-shows to optimize availability.</li>

                        </ul>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                <div class="text-center p-4">
                    <div class="d-inline-block rounded bg-light p-4 mb-4"><i
                            class="fas  fa-parking fa-5x text-secondary"></i></div>
                    <div class="feature-content">
                        <a href="#" class="h4">Parking Management <i class="fa fa-long-arrow-alt-right"></i></a>
                        <p class="mt-4 mb-0">
                        <ul class="text-start">
                            <li> Parking space allocation based on employee roles or hierarchy.</li>
                            <li> Visitor parking reservation and validation.</li>
                            <li> Parking availability indicators for employees and visitors.</li>
                            <li> Integration with access control systems for automated entry/exit.</li>

                        </ul>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                <div class="text-center rounded p-4">
                    <div class="d-inline-block rounded bg-light p-4 mb-4"><i
                            class="fas fa-sitemap fa-5x text-secondary"></i></div>
                    <div class="feature-content">
                        <a href="#" class="h4"> Compliance <i class="fa fa-long-arrow-alt-right"></i></a>
                        <p class="mt-4 mb-0">
                        <ul class="text-start">
                            <li> Role-based access control to ensure data security.</li>
                            <li> Compliance with GDPR and other data protection regulations.</li>
                            <li> Audit logs for tracking user activities and changes.</li>
                            <li> Encryption of sensitive data in transit and at rest.</li>

                        </ul>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-12 wow fadeInUp" data-wow-delay="0.1s">
                <div class="my-3">
                    <a href="<?php echo get_template_directory_uri(); ?>/services/"
                        class="btn btn-primary d-inline rounded-pill px-5 py-3">More Features</a>
                </div>
            </div>
        </div>
        <div class="row g-5 pt-5" style="margin-top: 6rem;">
            <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.1s">
                <div class="feature-img RotateMoveLeft h-100" style="object-fit: cover;">
                    <img src="/moveinsync/wp-content/themes/moveinsync/img/features-1.png" class="img-fluid w-100 h-100"
                        alt="">
                </div>
            </div>
            <div class="col-lg-6 wow fadeInRight" data-wow-delay="0.1s">
                <h4 class="text-primary">Fearutes</h4>
                <h1 class="display-5 mb-4">Push Your Visitors Into Happy Customers</h1>
                <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, suscipit
                    itaque quaerat dicta porro illum, autem, molestias ut animi ab aspernatur dolorum officia
                    nam
                    dolore. Voluptatibus aliquam earum labore atque.
                </p>

                <div class="my-4">
                    <a href="#" class="btn btn-primary rounded-pill py-3 px-5">Read More</a>
                </div>
            </div>
        </div>
    </div>
</div>


</div>
</div>
</div>
<!-- Feature End -->


<!-- Blog Start -->
<div class="container-fluid blog py-5">
    <div class="container py-5">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 900px;">
            <h4 class="text-primary">Our Blog</h4>
            <h1 class="display-5 mb-4">Join Us For New Blog</h1>
            <p class="mb-0">Dolor sit amet consectetur, adipisicing elit. Ipsam, beatae maxime. Vel animi eveniet
                doloremque reiciendis soluta iste provident non rerum illum perferendis earum est architecto dolores
                vitae quia vero quod incidunt culpa corporis, porro doloribus. Voluptates nemo doloremque cum.
            </p>
        </div>
        <div class="row g-4 justify-content-center">

            <?php 
        $blog_arry=array(
            'post-type' => 'post',
            'post_status' => 'publish',
            'tax_query' => array(),
                                    
                    );

        $blog_query = new WP_Query($blog_arry);

        while ($blog_query->have_posts()) {
            $blog_query->the_post();
            
        
        
        ?>


            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                <div class="blog-item d-flex flex-column h-100">
                    <div class="blog-img">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100" alt="">
                        <div class="blog-info">
                            <span><i class="fa fa-clock"></i> <?php echo get_the_date(); ?></span>
                            <div class="d-flex">
                                <span class="me-3"> 3 <i class="fa fa-heart"></i></span>
                                <a href="#" class="text-white">0 <i class="fa fa-comment"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="blog-content text-dark border p-4 flex-fill">
                        <h5 class="mb-4"><?php the_title() ?></h5>
                        <p class="mb-4"><?php echo wp_trim_words(get_the_content(), 20); ?></p>
                        <!-- Adjust '20' to the desired number of words -->
                        <a class="btn btn-light rounded-pill py-2 px-4 mt-auto"
                            href="<?php echo get_permalink(); ?>">Read More</a>
                    </div>
                </div>
            </div>


            <?php } ?>

        </div>
    </div>
</div>
<!-- Blog End -->


<?php 
get_footer();
?>