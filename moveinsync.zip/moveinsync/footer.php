<?php wp_footer(); ?>


<!-- Footer Start -->
<div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="text-dark mb-4">Company</h4>
                    <a href="<?php echo get_template_directory_uri(); ?>/about"> Why Office Optica ?</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/about"> Our Features</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/about"> Our Portfolio</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/about"> About Us</a>
                    <a href="#"> Our Blog & News</a>
                    <a href="#"> Get In Touch</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="mb-4 text-dark">Quick Links</h4>
                    <a href="<?php echo get_template_directory_uri(); ?>/about"> About Us</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/contact"> Contact Us</a>
                    <a href="#"> Privacy Policy</a>
                    <a href="#"> Terms & Conditions</a>
                    <a href="#"> Our Blog & News</a>

                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="mb-4 text-dark">Services</h4>
                    <a href="<?php echo get_template_directory_uri(); ?>/service"> All Services</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/service"> Desk Management</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/service"> Meeting Room Booking</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/service">Parking Management</a>
                    <a href="<?php echo get_template_directory_uri(); ?>/service"> Visitor Management</a>

                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="mb-4 text-dark">Contact Info</h4>
                    <a href=""><i class="fa fa-map-marker-alt me-2"></i> No. 439, 17th Cross Rd, Sector 4, HSR Layout,
                        Bengaluru, Karnataka 560102</a>
                    <a href="mailto:abhijitkumarsharma1505@gmail.com"><i class="fas fa-envelope me-2"></i>
                        abhijitkumarsharma1505@gmail.com</a>
                    <a href=""><i class="fas fa-phone me-2"></i> +91 806 193 7937</a>
                    <a href="" class="mb-3"><i class="fas fa-print me-2"></i>+91 806 193 7937</a>
                    <div class="d-flex align-items-center">
                        <i class="fas fa-share fa-2x text-secondary me-2"></i>
                        <a class="btn-square btn btn-primary rounded-circle mx-1 d-flex" href="#"><i
                                class="fab fa-facebook-f"></i></a>
                        <a class="btn-square btn btn-primary rounded-circle mx-1 d-flex" href="#"><i
                                class="fab fa-twitter"></i></a>
                        <a class="btn-square btn btn-primary rounded-circle mx-1 d-flex" href="#"><i
                                class="fab fa-instagram"></i></a>
                        <a class="btn-square btn btn-primary rounded-circle mx-1 d-flex" href="#"><i
                                class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


<!-- Copyright Start -->
<div class="container-fluid copyright py-4">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-md-6 text-center text-md-start mb-md-0">
                <span class="text-white"><a href="https://moveinsync.com/contact-us/"><i
                            class="fas fa-copyright text-light me-2"></i>MoveInSync
                        Technology Solutions Private Limited</a>, All right reserved.</span>
            </div>
            <div class="col-md-6 text-center text-md-end text-white">
                Designed By <a class="border-bottom"
                    href="https://www.linkedin.com/in/abhijit-kumar-sharma-468541133/">Abhijit Kr Sharma</a>
            </div>
        </div>
    </div>
</div>
<!-- Copyright End -->


<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>



</body>

</html>