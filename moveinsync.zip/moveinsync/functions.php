<?php

function main_style_enqueue() {
    // Enqueue your theme's style.css
    wp_enqueue_style('local-style-1', get_template_directory_uri().'/style.css', array(), '1.0.1', 'all');
    wp_enqueue_style('local-style-2', get_template_directory_uri().'/css/bootstrap.min.css', 'all');
    
    // Google Web Fonts
    wp_enqueue_style('Google-fonts', 'https://fonts.googleapis.com', array(), '1.0.0', 'all');
    wp_enqueue_style('Google-fonts-2', 'https://fonts.gstatic.com', array(), '1.0.0', 'all');
    wp_enqueue_style('Google-fonts-3', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700&family=Rubik:wght@400;500&display=swap', array(), '1.0.0', 'all');

    // Icon Font Stylesheet 
    wp_enqueue_style('font-icons', 'https://use.fontawesome.com/releases/v5.15.4/css/all.css', array(), '1.0.0', 'all');
    wp_enqueue_style('bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css', array(), '1.0.0', 'all');

    //Libraries Stylesheet
    
    wp_enqueue_style('Google-fonts-3',get_template_directory_uri().'/lib/animate/animate.min.css', array(), '1.0.0', 'all');
    wp_enqueue_style('Google-fonts-4',get_template_directory_uri().'/lib/owlcarousel/assets/owl.carousel.min.css', array(), '1.0.0', 'all');
    wp_enqueue_style('Google-fonts-5',get_template_directory_uri().'/   lib/lightbox/css/lightbox.min.css', array(), '1.0.0', 'all'); 
    
}

add_action('wp_enqueue_scripts', 'main_style_enqueue');


function moveinsyc_scripts(){

     // Enqueue Bootstrap JavaScript (version 4.0.0)
     wp_enqueue_script('bootstrap-new', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js', array('jquery'), '4.0.0', true);
    
    //JavaScript Libraries
     wp_enqueue_script('jquery','https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js', array('jquery'), '4.0.0', true);
     wp_enqueue_script('jquery-local',get_template_directory_uri().'/lib/wow/wow.min.js', array(), '4.0.0', true);
     wp_enqueue_script('jquery-local-2',get_template_directory_uri().'/lib/easing/easing.min.js', array(), '4.0.0', true);
     wp_enqueue_script('jquery-local-3',get_template_directory_uri().'/lib/waypoints/waypoints.min.js', array(), '4.0.0', true);
     wp_enqueue_script('jquery-local-4',get_template_directory_uri().'/lib/counterup/counterup.min.js', array(), '4.0.0', true);
     wp_enqueue_script('jquery-local-5',get_template_directory_uri().'/lib/owlcarousel/owl.carousel.min.js', array(), '4.0.0', true);
     wp_enqueue_script('jquery-local-6',get_template_directory_uri().'/lib/lightbox/js/lightbox.min.js', array(), '4.0.0', true);
    
     //Template Javascript
    wp_enqueue_script('local-scrpits',get_template_directory_uri().'/js/main.js', array(), '4.0.0', true);
    

   
}
add_action('wp_enqueue_scripts', 'moveinsyc_scripts');


// Add custom support
add_theme_support('custom-logo', array('height' => 480, 'width' => 720));
add_theme_support('title-tag');
add_theme_support('post-thumbnails');
add_theme_support('responsive-embeds');
add_theme_support('custom-header');


// Menu Regsiter 
register_nav_menus(
    array('primary-menu-key' => 'Primary Menu')
    
);

//Register Widget Areas

function theme_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Primary Sidebar', 'your-theme-textdomain' ),
        'id'            => 'primary-sidebar',
        'description'   => esc_html__( 'Wedigrt_sidebar', 'moveinsync' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'theme_widgets_init' );