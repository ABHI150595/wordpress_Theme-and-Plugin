         <?php
get_header(); ?>

         <div class="container-fluid bg-breadcrumb">
             <ul class="breadcrumb-animation">
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
                 <li></li>
             </ul>
             <div class="container text-center py-5" style="max-width: 900px;">
                 <h3 class="display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">Our Blog</h1>
                     <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                         <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>">Home</a></li>
                         <li class="breadcrumb-item active text-primary">Blog</li>
                     </ol>
             </div>
         </div>
         <!-- Header End -->


         <!-- Blog Start -->
         <div class="container-fluid blog py-5">
             <div class="container py-5">
                 <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 900px;">
                     <h4 class="text-primary">Our Blog</h4>
                     <h1 class="display-5 mb-4">Join Us For New Blog</h1>
                     <p class="mb-0">Dolor sit amet consectetur, adipisicing elit. Ipsam, beatae maxime. Vel animi
                         eveniet doloremque reiciendis soluta iste provident non rerum illum perferendis earum est
                         architecto dolores vitae quia vero quod incidunt culpa corporis, porro doloribus. Voluptates
                         nemo doloremque cum.
                     </p>
                 </div>
                 <div class="row g-4 justify-content-center">


                     <?php 
                            $blog_arry=array(
                            'post-type' => 'post',
                            'post_status' => 'publish',
                            'tax_query' => array(),
                                                    
                                    );

                            $blog_query = new WP_Query($blog_arry);

                            while ($blog_query->have_posts()) {
                            $blog_query->the_post();

                            ?>


                     <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                         <div class="blog-item d-flex flex-column h-100">
                             <div class="blog-img">
                                 <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100" alt="">
                                 <div class="blog-info">
                                     <span><i class="fa fa-clock"></i> <?php echo get_the_date(); ?></span>
                                     <div class="d-flex">
                                         <span class="me-3"> 3 <i class="fa fa-heart"></i></span>
                                         <a href="#" class="text-white">0 <i class="fa fa-comment"></i></a>
                                     </div>
                                 </div>
                             </div>
                             <div class="blog-content text-dark border p-4 flex-fill">
                                 <h5 class="mb-4"><?php the_title() ?></h5>
                                 <p class="mb-4"><?php echo wp_trim_words(get_the_content(), 20); ?></p>
                                 <!-- Adjust '20' to the desired number of words -->
                                 <a class="btn btn-light rounded-pill py-2 px-4 mt-auto"
                                     href="<?php echo get_permalink(); ?>">Read More</a>
                             </div>
                         </div>
                     </div>


                     <?php } ?>


                 </div>
             </div>
         </div>
         <!-- Blog End -->