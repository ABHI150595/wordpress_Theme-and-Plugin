<?php

// Silence is golden.